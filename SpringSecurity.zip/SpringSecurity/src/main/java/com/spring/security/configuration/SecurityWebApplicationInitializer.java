package com.spring.security.configuration;


/**
 * Below specified initializer class registers the springSecurityFilter [created in Step 3] with application war.
 */
import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

}
